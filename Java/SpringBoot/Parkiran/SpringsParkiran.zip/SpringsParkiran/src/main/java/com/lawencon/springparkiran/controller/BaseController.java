package com.lawencon.springparkiran.controller;

import org.springframework.beans.factory.annotation.Autowired;
import com.lawencon.springparkiran.service.KendaraanJpaService;
import com.lawencon.springparkiran.service.KendaraanHiberService;

abstract class BaseController {
	
	@Autowired
	protected KendaraanHiberService k_service;
	@Autowired
	protected KendaraanJpaService k_jpaservice;
}
