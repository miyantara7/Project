package com.lawencon.springparkiran.controller;
/*
 * 
 * @Author I KADEK ARYA YOGIMIYAANTARA
 * 
 */

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lawencon.springparkiran.model.Kendaraan;

@RestController
@RequestMapping("/kendaraan")
public class KendaraanController extends BaseController {

	@PostMapping("/checkin")
	public ResponseEntity<?> insertHhiber(@RequestBody String content, @RequestHeader("username") String user,
			@RequestHeader("password") String pass) {
		String pesan = "" ;
		try {
			Kendaraan kendaraan = new ObjectMapper().readValue(content, Kendaraan.class);
			pesan = k_service.insertKendaraan(kendaraan,user,pass);
			return new ResponseEntity<>(pesan, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(pesan, HttpStatus.BAD_REQUEST);
		}
		
	}

	@PostMapping("/checkout")
	public ResponseEntity<?> checkOut(@RequestBody String content, @RequestHeader("username") String user,
			@RequestHeader("password") String pass) {
		String pesan = "" ;
		try {
			Kendaraan kendaraan = new ObjectMapper().readValue(content, Kendaraan.class);
			pesan = k_service.insertCheckoutKendaraan(kendaraan,user,pass);
		} catch (Exception e) {
			return new ResponseEntity<>(pesan, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(pesan, HttpStatus.OK);
	}

	@GetMapping("/listcheckin")
	public ResponseEntity<List<Kendaraan>> getListCheckIn() {
		List<Kendaraan> listKendaraan = new ArrayList<>();
		try {
			listKendaraan = k_service.viewKendaraanCheckIn();
		} catch (Exception e) {
			return new ResponseEntity<>(listKendaraan, HttpStatus.OK);
		}
		return new ResponseEntity<>(listKendaraan, HttpStatus.OK);
	}

	@GetMapping("/listcheckout")
	public ResponseEntity<List<Kendaraan>> getListCheckOut() {
		List<Kendaraan> listKendaraan = new ArrayList<>();
		try {
			listKendaraan = k_service.viewKendaraanCheckOut();
		} catch (Exception e) {
			return new ResponseEntity<>(listKendaraan, HttpStatus.OK);
		}
		return new ResponseEntity<>(listKendaraan, HttpStatus.OK);
	}

	@PostMapping("/checkin/jpa")
	public ResponseEntity<?> insertJpa(@RequestBody String content, @RequestHeader("username") String user,
			@RequestHeader("password") String pass) {
		String pesan = "";
		try {
			Kendaraan kendaraan = new ObjectMapper().readValue(content, Kendaraan.class);
			pesan = k_jpaservice.insertKendaraanJpa(kendaraan,user,pass);
		} catch (Exception e) {
			return new ResponseEntity<>(pesan, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(pesan, HttpStatus.OK);
	}

	@PostMapping("/checkout/jpa")
	public ResponseEntity<?> checkOutJpa(@RequestBody String content, @RequestHeader("username") String user,
			@RequestHeader("password") String pass) {
		String pesan = "";
		try {
			Kendaraan kendaraan = new ObjectMapper().readValue(content, Kendaraan.class);
			pesan = k_jpaservice.insertCheckoutKendaraanJpa(kendaraan,user,pass);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(pesan, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(pesan, HttpStatus.OK);
	}

	@GetMapping("/listcheckin/jpa")
	public ResponseEntity<List<Kendaraan>> getListCheckInJpa() {
		List<Kendaraan> listKendaraan = new ArrayList<>();
		try {
			listKendaraan = k_service.viewKendaraanCheckIn();
		} catch (Exception e) {
			return new ResponseEntity<>(listKendaraan, HttpStatus.OK);
		}
		return new ResponseEntity<>(listKendaraan, HttpStatus.OK);
	}

	@GetMapping("/listcheckout/jpa")
	public ResponseEntity<List<Kendaraan>> getListCheckOutJpa() {
		List<Kendaraan> listKendaraan = new ArrayList<>();
		try {
			listKendaraan = k_service.viewKendaraanCheckOut();
		} catch (Exception e) {
			return new ResponseEntity<>(listKendaraan, HttpStatus.OK);
		}
		return new ResponseEntity<>(listKendaraan, HttpStatus.OK);
	}
}
