package com.lawencon.springparkiran.dao;

import java.util.List;

import com.lawencon.springparkiran.model.Kendaraan;

public interface KendaraanDao {

	abstract String insertKendaraan(Kendaraan kendaraan,String user,String pass) throws Exception;
	abstract Boolean validKendaraanCheckIn(Kendaraan kendaraan) throws Exception;
	abstract Boolean validKendaraanCheckOut(Kendaraan kendaraan) throws Exception;
	abstract String insertCheckoutKendaraan(Kendaraan kendaraan,String user,String pass) throws Exception;
	abstract List<Kendaraan> viewKendaraanCheckIn() throws Exception;
	abstract List<Kendaraan> viewKendaraanCheckOut() throws Exception;
	
	abstract String insertKendaraanJpa(Kendaraan kendaraan,String user,String pass) throws Exception;
	abstract String insertCheckoutKendaraanJpa(Kendaraan kendaraan,String user,String pass) throws Exception;
	abstract List<Kendaraan> viewKendaraanCheckInJpa() throws Exception;
	abstract List<Kendaraan> viewKendaraanCheckOutJpa() throws Exception;
}
