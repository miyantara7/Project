package com.lawencon.springparkiran.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lawencon.springparkiran.dao.KendaraanDao;
import com.lawencon.springparkiran.model.Kendaraan;
import com.lawencon.springparkiran.repo.CustomRepo;
import com.lawencon.springparkiran.repo.KendaraanRepo;

@Service
@Transactional
public class KendaraanDaoImpl extends CustomRepo implements KendaraanDao{

	@Autowired
	private KendaraanRepo kendaraanRepo;

	@Autowired
	private UserService userService;
	
	@Override
	public String insertKendaraan(Kendaraan kendaraan, String user, String pass) throws Exception {
		if (userService.validuser(user, pass) == true) {
			if (validKendaraanCheckIn(kendaraan) == false) {
				return "Gagal insert kendaraan";
			} else {
				em.persist(kendaraan);
				return "Berhasil";
			}
		} else {
			return "Username atau password salah !";
		}
	}

	@Override
	public Boolean validKendaraanCheckIn(Kendaraan kendaraan) throws Exception {
		Kendaraan ken2 = null;
		Query q = em.createQuery("from Kendaraan where noPlat =: noParam").setParameter("noParam",
				kendaraan.getNoPlat().toLowerCase());
		try {
			ken2 = (Kendaraan) q.getSingleResult();
		} catch (Exception e) {

		}
		if (ken2 != null) {
			if (kendaraan.getNoPlat().replaceAll("\\s+", "").toLowerCase().substring(0, 1).equals("b")) {
				try {
					Integer.parseInt(kendaraan.getNoPlat().substring(1, 5));
					if (kendaraan.getNoPlat().substring(1, 5).length() <= 4
							&& kendaraan.getNoPlat().substring(1, 5).length() >= 1) {
						try {
							Integer.parseInt(kendaraan.getNoPlat().substring(5, 8));
							return false;
						} catch (Exception e) {
							if (ken2.getNoPlat().toLowerCase().equals(kendaraan.getNoPlat().toLowerCase())
									&& ken2.getTanggalMasuk().equals(kendaraan.getTanggalMasuk())) {
								return false;
							} else {
								return true;
							}
						}
					} else {
						return false;
					}
				} catch (Exception e) {
					return false;
				}
			} else {
				return false;
			}

		} else {
			return true;
		}
	}

	@Override
	public Boolean validKendaraanCheckOut(Kendaraan kendaraan) throws Exception {
		Kendaraan ken2 = null;
		Query q = em.createQuery("from Kendaraan where noPlat =: noParam and tanggalKeluar is null")
				.setParameter("noParam", kendaraan.getNoPlat().toLowerCase());
		try {
			ken2 = (Kendaraan) q.getSingleResult();
		} catch (Exception e) {
			return false;
		}
		if (ken2 != null) {
			if (kendaraan.getNoPlat().replaceAll("\\s+", "").toLowerCase().substring(0, 1).equals("b")) {
				try {
					Integer.parseInt(kendaraan.getNoPlat().substring(1, 5));
					if (kendaraan.getNoPlat().substring(1, 5).length() <= 4
							&& kendaraan.getNoPlat().substring(1, 5).length() >= 1) {
						try {
							Integer.parseInt(kendaraan.getNoPlat().substring(5, 8));
							return false;
						} catch (Exception e) {
							return true;
						}
					} else {
						return false;
					}
				} catch (Exception e) {
					return false;
				}
			} else {
				return false;
			}

		} else {
			return false;
		}
	}

	@Override
	public String insertCheckoutKendaraan(Kendaraan kendaraan, String user, String pass) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		Query q = em.createQuery("from Kendaraan where noPlat =: noParam and tanggalKeluar is null")
				.setParameter("noParam", kendaraan.getNoPlat().toLowerCase());
		try {
			kendaraan = (Kendaraan) q.getSingleResult();
			kendaraan.setTanggalKeluar(String.valueOf(dateFormat.format(date)));
		} catch (Exception e) {

		}

		if (userService.validuser(user, pass) == true) {
			if (validKendaraanCheckOut(kendaraan) == false) {
				em.merge(kendaraan);
				return "Berhasil";
			} else {
				return "Kendaraan tidak ada !";
			}
		} else {
			return "Username atau password salah !";
		}
	}

	@Override
	public List<Kendaraan> viewKendaraanCheckIn() throws Exception {
		Query q = em.createQuery("from Kendaraan where tanggalKeluar is null");
		return q.getResultList();
	}

	@Override
	public List<Kendaraan> viewKendaraanCheckOut() throws Exception {
		Query q = em.createQuery("from Kendaraan where tanggalKeluar is not null");
		return q.getResultList();
	}

	@Override
	public String insertKendaraanJpa(Kendaraan kendaraan, String user, String pass) throws Exception {
		if (userService.validuser(user, pass) == true) {
			if (validKendaraanCheckIn(kendaraan) == false) {
				return "Gagal insert kendaraan";
			} else {
				kendaraanRepo.save(kendaraan);
				return "Berhasil";
			}
		} else {
			return "Username atau password salah !";
		}
	}

	@Override
	public String insertCheckoutKendaraanJpa(Kendaraan kendaraan, String user, String pass) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		Query q = em.createQuery("from Kendaraan where noPlat =: noParam and tanggalKeluar is null")
				.setParameter("noParam", kendaraan.getNoPlat().toLowerCase());
		try {
			kendaraan = (Kendaraan) q.getSingleResult();
			kendaraan.setTanggalKeluar(String.valueOf(dateFormat.format(date)));
		} catch (Exception e) {

		}

		if (userService.validuser(user, pass) == true) {
			if (validKendaraanCheckOut(kendaraan) == false) {
				kendaraanRepo.save(kendaraan);
				return "Berhasil";
			} else {
				return "Kendaraan tidak ada !";
			}
		} else {
			return "Username atau password salah !";
		}
	}

	@Override
	public List<Kendaraan> viewKendaraanCheckInJpa() throws Exception {
		Query q = em.createNamedQuery("select *from kendaraan where tanggalKeluar is null ");
		return q.getResultList();
	}

	@Override
	public List<Kendaraan> viewKendaraanCheckOutJpa() throws Exception {
		Query q = em.createNamedQuery("select *from kendaraan where tanggalKeluar is not null ");
		return q.getResultList();
	}

}
