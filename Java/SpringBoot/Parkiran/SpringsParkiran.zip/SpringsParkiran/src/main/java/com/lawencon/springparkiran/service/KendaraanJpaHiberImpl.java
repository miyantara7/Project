package com.lawencon.springparkiran.service;

import java.util.List;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.lawencon.springparkiran.dao.KendaraanDao;
import com.lawencon.springparkiran.model.Kendaraan;
import com.lawencon.springparkiran.repo.CustomRepo;

@Service
@Transactional
public class KendaraanJpaHiberImpl extends CustomRepo implements KendaraanHiberService, KendaraanJpaService {

	@Autowired
	private KendaraanDao kenDao;

	@Override
	public String insertKendaraan(Kendaraan kendaraan, String user, String pass) throws Exception {
		return kenDao.insertKendaraan(kendaraan, user, pass);
	}

	@Override
	public String insertCheckoutKendaraan(Kendaraan kendaraan, String user, String pass) throws Exception {
		return kenDao.insertCheckoutKendaraan(kendaraan, user, pass);

	}

	@Override
	public Boolean validKendaraanCheckIn(Kendaraan kendaraan) throws Exception {
		return kenDao.validKendaraanCheckIn(kendaraan);
	}

	@Override
	public Boolean validKendaraanCheckOut(Kendaraan kendaraan) throws Exception {
		return kenDao.validKendaraanCheckOut(kendaraan);
	}

	@Override
	public List<Kendaraan> viewKendaraanCheckIn() throws Exception {
		return kenDao.viewKendaraanCheckIn();
	}

	@Override
	public List<Kendaraan> viewKendaraanCheckOut() throws Exception {
		return kenDao.viewKendaraanCheckOut();
	}

	@Override
	public String insertKendaraanJpa(Kendaraan kendaraan, String user, String pass) throws Exception {
		return kenDao.insertKendaraanJpa(kendaraan, user, pass);

	}

	@Override
	public String insertCheckoutKendaraanJpa(Kendaraan kendaraan, String user, String pass) throws Exception {
		return kenDao.insertCheckoutKendaraanJpa(kendaraan, user, pass);
	}

	@Override
	public List<Kendaraan> viewKendaraanCheckInJpa() throws Exception {
		return kenDao.viewKendaraanCheckInJpa();
	}

	@Override
	public List<Kendaraan> viewKendaraanCheckOutJpa() throws Exception {
		return kenDao.viewKendaraanCheckOutJpa();
	}

}
