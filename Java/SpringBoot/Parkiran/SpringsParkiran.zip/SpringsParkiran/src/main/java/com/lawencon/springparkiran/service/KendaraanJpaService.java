package com.lawencon.springparkiran.service;

import java.util.List;

import com.lawencon.springparkiran.model.Kendaraan;

public interface KendaraanJpaService {
	
	abstract String insertKendaraanJpa(Kendaraan kendaraan,String user,String pass) throws Exception;
	abstract String insertCheckoutKendaraanJpa(Kendaraan kendaraan,String user,String pass) throws Exception;
	abstract List<Kendaraan> viewKendaraanCheckInJpa() throws Exception;
	abstract List<Kendaraan> viewKendaraanCheckOutJpa() throws Exception;
}
