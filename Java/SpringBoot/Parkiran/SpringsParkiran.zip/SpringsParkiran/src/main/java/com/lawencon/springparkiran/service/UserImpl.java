package com.lawencon.springparkiran.service;

import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Service;

import com.lawencon.springparkiran.model.User;
import com.lawencon.springparkiran.repo.CustomRepo;

@Service
@Transactional
public class UserImpl extends CustomRepo implements UserService {

	@Override
	public Boolean validuser(String user, String pass) throws Exception {
		
		User users = null;
		Query q = em.createQuery("from User where username =: userParam and password =: passParam")
				.setParameter("userParam", user)
				.setParameter("passParam", pass);
		
		try {
			users = (User) q.getSingleResult(); 		
		} catch (Exception e) {
			
		}
		
		if(users != null) {
			return true;
		}else {
			return false;
		}

	}

}
