package com.lawencon.springparkiran.service;

public interface UserService {
	
	abstract Boolean validuser(String user, String pass) throws Exception;

}
